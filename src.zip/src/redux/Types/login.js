export const LOGGING_IN = "LOGGING_IN";
export const LOGGING_OUT = "LOGGING_OUT";
